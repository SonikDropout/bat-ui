<script>
  let state = STATES.initial;
</script>

<div class={state}>HELLO WORLD!</div>
